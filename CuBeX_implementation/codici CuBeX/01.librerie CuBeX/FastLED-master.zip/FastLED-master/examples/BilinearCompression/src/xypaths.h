

#include "fl/xypath.h"
#include "fl/vector.h"

using namespace fl;

 // XYPath::NewRosePath(WIDTH, HEIGHT);

fl::vector<XYPathPtr> CreateXYPaths(int width, int height);